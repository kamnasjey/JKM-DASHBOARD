import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth-options"
import { isOwnerEmail } from "@/lib/owner"
import { prisma } from "@/lib/db"

export async function requireSession() {
  const session = await getServerSession(authOptions)
  if (!session) {
    return null
  }
  return session
}

export async function requireAllowedSession() {
  const session = await getServerSession(authOptions)
  if (!session?.user) return null

  const email = (session.user as any).email
  
  // Owner/admin always has access
  if (isOwnerEmail(email)) return session

  // Check database for user access
  const userId = (session.user as any).id as string | undefined
  if (!userId) return null

  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: { hasPaidAccess: true },
  })

  if (!user?.hasPaidAccess) return null
  return session
}

// Legacy alias - now just checks allowed access instead of paid
export async function requirePaidSession() {
  return requireAllowedSession()
}

export function json(status: number, body: unknown) {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      "content-type": "application/json",
    },
  })
}
