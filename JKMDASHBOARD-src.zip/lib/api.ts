/**
 * All protected API calls go through /api/proxy/* endpoints.
 * The Next.js server verifies the NextAuth session and forwards
 * requests to the backend with the internal API key.
 */

export interface ApiError {
  message: string
  status: number
}

function toMessage(text: string): string {
  return text.replace(/^"|"$/g, "").trim()
}

// Fetch wrapper
export async function apiFetch<T>(path: string, options: RequestInit = {}): Promise<T> {
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    ...((options.headers as Record<string, string>) || {}),
  }

  try {
    const response = await fetch(path, { ...options, headers })

    if (response.status === 401) {
      if (typeof window !== "undefined") {
        window.location.href = "/auth/login"
      }
      throw new Error("Unauthorized")
    }

    // 402/403 - Access denied (will be handled by AccessDeniedGuard)
    if (response.status === 402 || response.status === 403) {
      throw new Error("Хандах эрхгүй")
    }

    if (!response.ok) {
      const contentType = response.headers.get("content-type") ?? ""
      const rawText = await response.text()

      if (contentType.includes("application/json")) {
        try {
          const data = JSON.parse(rawText)

          const candidate =
            (data && typeof data === "object" &&
              ((data as any).message ?? (data as any).error ?? (data as any).detail)) ||
            (typeof data === "string" ? data : null)

          if (candidate) {
            if (typeof candidate === "string") throw new Error(candidate)
            if (typeof candidate === "number" || typeof candidate === "boolean") {
              throw new Error(String(candidate))
            }
            // Object/array detail
            throw new Error(JSON.stringify(candidate))
          }

          // If backend returned JSON but no message fields, show something meaningful.
          throw new Error(`API Error (${response.status}): ${rawText || "Unknown"}`)
        } catch {
          // fall through to plain text
        }
      }

      const msg = toMessage(rawText)
      throw new Error(msg || `API Error (${response.status}) ${response.statusText}`)
    }

    return response.json()
  } catch (err: any) {
    if (err.message === "Failed to fetch" || err instanceof TypeError) {
      console.warn("[api] Network error:", path)
    }
    throw err
  }
}

export const api = {
  // Metrics
  getMetrics: () => apiFetch<any>("/api/proxy/metrics"),
  metrics: () => apiFetch<any>("/api/proxy/metrics"),

  // Signals
  getSignals: (params?: { limit?: number; symbol?: string }) => {
    const qs = new URLSearchParams()
    qs.set("limit", String(params?.limit ?? 50))
    if (params?.symbol) qs.set("symbol", params.symbol)
    return apiFetch<any[]>(`/api/proxy/signals?${qs.toString()}`)
  },
  signals: (params?: { limit?: number; symbol?: string }) => api.getSignals(params),

  // Symbols
  getSymbols: () => apiFetch<string[]>("/api/proxy/symbols"),
  symbols: () => api.getSymbols(),

  // Strategies
  getStrategies: () => apiFetch<any>("/api/proxy/strategies"),
  strategies: () => api.getStrategies(),
  updateStrategies: (data: any) =>
    apiFetch("/api/proxy/strategies", {
      method: "PUT",
      body: JSON.stringify(data),
    }),

  // Outcomes (SL/TP hit tracking)
  outcomes: (days: number = 30) =>
    apiFetch<any>(`/api/proxy/outcomes?days=${days}`),

  // Logs
  getLogs: () => apiFetch<string[]>("/api/proxy/log"),
  logs: () => api.getLogs(),

  // Health (public)
  getHealth: () => apiFetch<{ status: string }>("/api/proxy/health"),
  health: () => api.getHealth(),

  // Annotations
  annotations: (symbol: string) =>
    apiFetch<any>(`/api/proxy/annotations?symbol=${encodeURIComponent(symbol)}`),

  // Profile
  profile: () => apiFetch<any>("/api/proxy/profile"),
  updateProfile: (payload: any) =>
    apiFetch<any>("/api/proxy/profile", {
      method: "PUT",
      body: JSON.stringify(payload),
    }),

  // Engine controls
  engineStatus: () => apiFetch<any>("/api/proxy/engine/status"),
  manualScan: () => apiFetch<any>("/api/proxy/engine/manual-scan", { method: "POST" }),
  startScan: () => apiFetch<any>("/api/proxy/engine/start", { method: "POST" }),
  stopScan: () => apiFetch<any>("/api/proxy/engine/stop", { method: "POST" }),

  // Admin backfill
  backfill: (payload: any) =>
    apiFetch<any>("/api/proxy/admin/backfill", {
      method: "POST",
      body: JSON.stringify(payload),
    }),

  // Signal detail
  signalDetail: (id: string) => apiFetch<any>(`/api/proxy/signals/${id}`),

  // Signal AI explanation
  explainSignal: (signalId: string) => 
    apiFetch<{
      ok: boolean
      signal_id: string
      explain_type: "ai" | "basic"
      explanation: string
      signal_summary?: {
        symbol: string
        direction: string
        entry: number
        sl: number
        tp: number
        rr: number
      }
      ai_error?: string
    }>(`/api/proxy/signals/${signalId}/explain`, { method: "POST" }),

  // Candles for charting
  candles: (symbol: string, tf: string = "M5", limit: number = 200) =>
    apiFetch<any>(`/api/proxy/markets/${encodeURIComponent(symbol)}/candles?tf=${tf}&limit=${limit}`),

  // Detectors list
  detectors: () => apiFetch<any>("/api/proxy/detectors"),

  // Detailed metrics for performance dashboard
  detailedMetrics: () => apiFetch<any>("/api/proxy/metrics/detailed"),

  // Backtest - historical signals
  backtest: (params: {
    strategy_id?: string
    detectors?: string[]
    symbol?: string
    days?: number
  }) =>
    apiFetch<any>("/api/proxy/backtest", {
      method: "POST",
      body: JSON.stringify(params),
    }),

  // Backtest Simulation - run detectors on historical candle data
  backtestSimulate: (params: {
    strategy_id?: string
    detectors?: string[]
    symbol?: string
    days?: number
    min_rr?: number
  }) =>
    apiFetch<any>("/api/proxy/backtest/simulate", {
      method: "POST",
      body: JSON.stringify(params),
    }),

  // Shared strategies (public library)
  sharedStrategies: () => apiFetch<any>("/api/proxy/strategies/shared"),
  
  shareStrategy: (strategy: {
    strategy_id: string
    detectors: string[]
    min_score?: number
    min_rr?: number
    allowed_regimes?: string[]
    description?: string
  }) =>
    apiFetch<any>("/api/proxy/strategies/share", {
      method: "POST",
      body: JSON.stringify(strategy),
    }),
  
  importStrategy: (shareId: string) =>
    apiFetch<any>(`/api/proxy/strategies/import/${shareId}`, {
      method: "POST",
    }),
  
  // Strategy Tester API
  strategyTester: {
    run: (params: {
      symbol: string
      detectors: string[]
      entry_tf?: string
      trend_tf?: string
      start_date?: string
      end_date?: string
      spread_pips?: number
      slippage_pips?: number
      commission_per_trade?: number
      initial_capital?: number
      risk_per_trade_pct?: number
      intrabar_policy?: "sl_first" | "tp_first" | "bar_magnifier" | "random"
      min_rr?: number
      min_score?: number
      max_trades_per_day?: number
      max_bars_in_trade?: number
    }) =>
      apiFetch<any>("/api/proxy/strategy-tester/run", {
        method: "POST",
        body: JSON.stringify(params),
      }),
    
    listRuns: (limit = 50, offset = 0) =>
      apiFetch<any>(`/api/proxy/strategy-tester/runs?limit=${limit}&offset=${offset}`),
    
    getRun: (runId: string) =>
      apiFetch<any>(`/api/proxy/strategy-tester/runs/${runId}`),
    
    getTrades: (runId: string) =>
      apiFetch<any>(`/api/proxy/strategy-tester/runs/${runId}/trades`),
    
    getEquityCurve: (runId: string) =>
      apiFetch<any>(`/api/proxy/strategy-tester/runs/${runId}/equity`),
    
    deleteRun: (runId: string) =>
      apiFetch<any>(`/api/proxy/strategy-tester/runs/${runId}`, {
        method: "DELETE",
      }),
  },

  // Strategy Simulator API (new, replaces strategyTester)
  simulator: {
    run: (params: {
      symbol: string
      timeframe: string
      strategy_id: string
      range: {
        mode: "PRESET" | "CUSTOM"
        preset?: "7D" | "30D" | "90D" | "6M" | "1Y"
        from_ts?: number
        to_ts?: number
      }
      assumptions?: {
        intrabar_policy?: "SL_FIRST" | "TP_FIRST"
        spread?: number
        slippage?: number
        commission?: number
        max_trades?: number
      }
    }) =>
      apiFetch<{
        ok: boolean
        symbol?: string
        timeframe?: string
        from_ts?: number
        to_ts?: number
        strategy_id?: string
        summary?: {
          entries: number
          tp_hits: number
          sl_hits: number
          winrate: number
          avg_r: number
          profit_factor: number | null
          avg_duration_bars: number
          total_r: number
        }
        trades?: Array<{
          entry_ts: number
          exit_ts: number
          direction: "BUY" | "SELL"
          entry: number
          sl: number
          tp: number
          outcome: "TP" | "SL"
          r: number
          duration_bars: number
          detector: string
        }>
        warnings?: string[]
        error?: {
          code: string
          message: string
          details?: any
        }
      }>("/api/proxy/strategy-sim/run", {
        method: "POST",
        body: JSON.stringify(params),
      }),

    symbols: () =>
      apiFetch<{ ok: boolean; symbols: string[] }>("/api/proxy/strategy-sim/symbols"),
  },
}
