import { redirect } from "next/navigation"

export default function StrategyMakerPage() {
  redirect("/strategies/maker")
}
